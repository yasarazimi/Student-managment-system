import tkinter as tk
import mysql.connector
from tkinter import *
import pymysql


def submitact():
	
	user = Username.get()
	passw = password.get()

	print(f"The name entered by you is {user} {passw}")

	logintodb(user, passw)


def logintodb(user, passw):
	
	# If password is enetered by the
	# user
	if passw:
		db = mysql.connector.connect(host ="127.0.0.1",
									user = root,
									password = "suliman.12345",
                                    db ="student_management_system")
                                    
		cursor = db.cursor()
        
	# If no password is enetered by the
	# user
	else:
		db = mysql.connector.connect(host ="127.0.0.1",
									user = root,
									db ="student_management_system")
		cursor = db.cursor()
		
	# A Table in the database
	savequery = "select * from students"
	
	try:
		cursor.execute(savequery)
		myresult = cursor.fetchall()
		
		# Printing the result of the
		# query
		for x in myresult:
			print(x)
		print("Query Executed successfully")
		
	except:
		db.rollback()
		print("Error occured")

root = tk.Tk()
root.geometry("300x300")
root.title("DBMS Login Page")
root['bg']='#5d8a82'


# Defining the first row
lblfrstrow = tk.Label(root, text ="Username -", )
lblfrstrow.place(x = 50, y = 20)

Username = tk.Entry(root, width = 35)
Username.place(x = 150, y = 20, width = 100)

lblsecrow = tk.Label(root, text ="Password -")
lblsecrow.place(x = 50, y = 50)

password = tk.Entry(root, width = 35)
password.place(x = 150, y = 50, width = 100)

submitbtn = tk.Button(root, text ="Signin",
					bg ='grey', command = submitact)
submitbtn.place(x = 150, y = 135, width = 55)

def nextPage():
    root.destroy()
    import tkinter1

button1 = tk.Button(root,text = "Login page",
                    bg='grey' , command=nextPage)
button1.place(x=70, y=135, width=65)

root.mainloop()

