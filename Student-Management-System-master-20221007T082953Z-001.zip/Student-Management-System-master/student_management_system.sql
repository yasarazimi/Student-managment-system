SELECT * FROM student_management_system.students;
